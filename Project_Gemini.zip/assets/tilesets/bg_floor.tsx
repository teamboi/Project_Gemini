<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="bg_floor" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="bg_floor.png" width="128" height="128"/>
 <tile id="1">
  <objectgroup draworder="index">
   <object id="1" x="16" y="13.1712">
    <properties>
     <property name="collision" type="bool" value="false"/>
    </properties>
    <polygon points="-12.6667,-29.1171 -11.3333,16.1622 14,16.1622 15.3333,3.16216"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index">
   <object id="1" x="4.66667" y="-31.3333" width="22.6667" height="64.6667">
    <ellipse/>
   </object>
  </objectgroup>
 </tile>
</tileset>
