<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="pixel3" tilewidth="8" tileheight="8" tilecount="1" columns="1">
 <image source="../img/objects/Pixel3.png" width="8" height="8"/>
</tileset>
