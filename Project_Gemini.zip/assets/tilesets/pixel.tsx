<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="pixel" tilewidth="1" tileheight="1" tilecount="1" columns="1">
 <image source="Pixel.png" width="1" height="1"/>
</tileset>
