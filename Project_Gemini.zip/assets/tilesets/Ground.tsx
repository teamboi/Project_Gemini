<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="Ground" tilewidth="512" tileheight="32" tilecount="99" columns="9">
 <image source="120 blue floor.png" width="4800" height="376"/>
</tileset>
