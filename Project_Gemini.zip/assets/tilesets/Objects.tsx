<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="Objects" tilewidth="32" tileheight="32" tilecount="340" columns="17">
 <image source="120_tileset.png" width="544" height="642"/>
</tileset>
