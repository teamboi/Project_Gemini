# Project_Gemini, 120 Final Project
AKA Cat's Cradle, A 2 player game of string, created by TEAM BOY
TEAM BOY is Erica Li, Herman Wu, and Georgio Klironomos

# prefixes:
# spr_sprite
# anim_animation
# sfx_sound
# No spaces; underscore_please_for_files_like_art_assets
# camelCase