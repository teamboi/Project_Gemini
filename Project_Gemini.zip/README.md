# Project_Gemini
Untitled cats &amp; string game

# prefixes:
# spr_sprite
# anim_animation
# sfx_sound
# No spaces; underscore_please_for_files_like_art_assets
# camelCase